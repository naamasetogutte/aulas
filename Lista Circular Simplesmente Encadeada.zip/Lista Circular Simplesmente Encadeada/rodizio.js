const fs = require('fs'); // Módulo para ler arquivos
const readline = require('readline'); // Módulo para entrada de dados do usuário

// Classe que representa um nó da lista circular
class No {
    constructor(placa, dia) {
        this.placa = placa; // Placa do veículo (ex: ABC1234)
        this.dia = dia;     // Dia do rodízio (ex: segunda, terça)
        this.prox = null;   // Ponteiro para o próximo nó
    }
}

// Classe para gerenciar a lista circular
class ListaCircular {
    constructor() {
        this.inicio = null; // Início da lista
    }

    // Cria e insere um novo nó na lista circular
    inserirCircular(placa, dia) {
        const novo = new No(placa, dia);

        if (!this.inicio) {
            // Se a lista estiver vazia, o nó aponta pra si mesmo
            this.inicio = novo;
            novo.prox = novo;
        } else {
            // Se a lista já tiver elementos, percorre até o último
            let temp = this.inicio;
            while (temp.prox !== this.inicio) {
                temp = temp.prox;
            }
            temp.prox = novo;     // Último nó aponta pro novo
            novo.prox = this.inicio; // Novo aponta pro início, mantendo a circularidade
        }
    }

    // Carrega os veículos de um arquivo filtrando pelo dia do rodízio
    carregarVeiculos(diaFiltro) {
        try {
            const dados = fs.readFileSync('rodizio_de_veiculos.txt', 'utf-8');
            const linhas = dados.split('\n');

            for (let linha of linhas) {
                const [placa, dia] = linha.trim().split(' ');
                if (dia === diaFiltro) {
                    this.inserirCircular(placa, dia);
                }
            }
        } catch (err) {
            console.error("Erro ao abrir o arquivo:", err.message);
        }
    }

    // Permite navegar interativamente pela lista circular
    async navegar() {
        if (!this.inicio) {
            console.log("Nenhum veículo encontrado para este dia.");
            return;
        }

        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });

        let atual = this.inicio;

        const perguntar = () => {
            console.log(`Placa: ${atual.placa} | Dia: ${atual.dia}`);
            rl.question("Digite 'n' para próximo, 's' para sair: ", (comando) => {
                if (comando === 'n') {
                    atual = atual.prox; // Vai para o próximo nó
                    perguntar();        // Repete o processo
                } else {
                    rl.close();         // Encerra o programa
                }
            });
        };

        perguntar();
    }

    // Libera todos os nós (simula liberação de memória)
    liberarLista() {
        if (!this.inicio) return;

        let atual = this.inicio.prox;
        while (atual !== this.inicio) {
            let temp = atual;
            atual = atual.prox;
            temp.prox = null;
        }
        this.inicio = null; // Libera o início
    }
}

// Função principal que roda o programa
async function main() {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    rl.question("Digite o dia do rodízio (ex: segunda, terca, quarta): ", async (diaFiltro) => {
        const lista = new ListaCircular();
        lista.carregarVeiculos(diaFiltro); // Lê o arquivo e filtra
        await lista.navegar();             // Começa a navegação interativa
        lista.liberarLista();              // Limpa a lista
        rl.close();
    });
}

main(); // Executa o programa
