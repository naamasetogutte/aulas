package org.example;

public class Banco {
    public static void main(String[] args) {
        ContaCorrente inter = new ContaCorrente("0001","300.00","Naamã","1000.0");

        System.out.println("Titular = " + inter.getTitular());
        System.out.println("Saldo = " + inter.getSaldo());
        System.out.println("Saque:");
        inter.sacar(100.00);

    }
}
