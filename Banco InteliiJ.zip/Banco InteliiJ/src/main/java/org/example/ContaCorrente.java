package org.example;

public class ContaCorrente extends ContaBancaria{

    private double limiteConta;

    public ContaCorrente(String numeroConta, String saldo, String titular, String limiteConta) {
        super(numeroConta, titular, Double.parseDouble(saldo));
    }


    public double getLimiteConta() {
        return limiteConta;
    }

    @Override
    public void sacar(double saque) {
        double saldo =  getSaldo();
        double valor = getSaldo() + limiteConta;
        if(valor >= saque){
            valor -= saque;
            System.out.println("Saque realizado Saldo atual" + valor);
        }else{
            System.out.println("Saldo insuficiente!");
        }
    }

    @Override
    public void ExibirTipoConta() {
        System.out.println("Conta corrente ");
    }
}
