package org.example;

public class ContaSalario {

}
