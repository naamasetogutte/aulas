const fs = require('fs');
const readline = require('readline'); 

class No {
    constructor(placa, dia) {
        this.placa = placa; 
        this.dia = dia;     
        this.prox = null;   
    }
}

class ListaCircular {
    constructor() {
        this.inicio = null;
    }

    inserirCircular(placa, dia) {
        const novo = new No(placa, dia);

        if (!this.inicio) {

            this.inicio = novo;
            novo.prox = novo;
        } else {

            let temp = this.inicio;
            while (temp.prox !== this.inicio) {
                temp = temp.prox;
            }
            temp.prox = novo;    
            novo.prox = this.inicio; 
        }
    }

    carregarVeiculos(diaFiltro) {
        try {
            const dados = fs.readFileSync('rodizio_de_veiculos.txt', 'utf-8');
            const linhas = dados.split('\n');

            for (let linha of linhas) {
                const [placa, dia] = linha.trim().split(' ');
                if (dia === diaFiltro) {
                    this.inserirCircular(placa, dia);
                }
            }
        } catch (err) {
            console.error("Erro ao abrir o arquivo:", err.message);
        }
    }

    async navegar() {
        if (!this.inicio) {
            console.log("Nenhum veículo encontrado para este dia.");
            return;
        }

        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });

        let atual = this.inicio;

        const perguntar = () => {
            console.log(`Placa: ${atual.placa} | Dia: ${atual.dia}`);
            rl.question("Digite 'n' para próximo, 's' para sair: ", (comando) => {
                if (comando === 'n') {
                    atual = atual.prox;
                    perguntar();      
                } else {
                    rl.close();      
                }
            });
        };

        perguntar();
    }

    liberarLista() {
        if (!this.inicio) return;

        let atual = this.inicio.prox;
        while (atual !== this.inicio) {
            let temp = atual;
            atual = atual.prox;
            temp.prox = null;
        }
        this.inicio = null;
    }
}

async function main() {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    rl.question("Digite o dia do rodízio (ex: segunda, terca, quarta): ", async (diaFiltro) => {
        const lista = new ListaCircular();
        lista.carregarVeiculos(diaFiltro); 
        await lista.navegar();          
        lista.liberarLista();       
        rl.close();
    });
}

main();
