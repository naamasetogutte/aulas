package org.example;

public class Main {
    public static void main(String[] args) {
        Cavalo cavalo = new Cavalo("Cavalo", "Equino");
        Peixe peixe = new Peixe("Peixo", "Nemo");
        Gaviao gaviao = new Gaviao("Gaviao", "Fiel");
        Pato pato = new Pato("Pato", "FullStack");

        cavalo.andar();
        peixe.nadar();
        gaviao.voar();
        pato.andar();
        pato.nadar();
        pato.voar();



    }
}
