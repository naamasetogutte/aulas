package org.example;

public interface Aquatica {

    void nadar();

}
