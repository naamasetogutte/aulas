package org.example;

public class Animal {
    private String nome;
    private String especie;
    private String idade;

    public Animal(String nome, String especie) {
        this.nome = nome;
        this.especie = especie;
    }

    public String getNome() {
        return nome;
    }

    public String getEspecie() {
        return especie;
    }

    public String getIdade() {
        return idade;
    }

    public void setIdade(String idade) {
        this.idade = idade;
    }

    public void comer(){
        System.out.println(nome + "Esta comendo!");
    }

    public void dormir(){
        System.out.println(nome + "Esta dormindo!");
    }


}
