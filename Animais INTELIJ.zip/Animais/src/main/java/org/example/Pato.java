package org.example;

import javax.sound.midi.Soundbank;

public class Pato extends Animal implements Voador, Terrestre, Aquatica{
    public Pato(String nome, String especie) {
        super(nome, especie);
    }

    @Override
    public void nadar() {
        System.out.println(getNome()+ " esta nadando");
    }

    @Override
    public void andar() {
        System.out.println(getNome()+ " esta andando");
    }

    @Override
    public void voar() {
        System.out.println(getNome()+ " esta voando");
    }
}
