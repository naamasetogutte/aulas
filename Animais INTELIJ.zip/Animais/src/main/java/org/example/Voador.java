package org.example;

public interface Voador {
    void voar();
}
