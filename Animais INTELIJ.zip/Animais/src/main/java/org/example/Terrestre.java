package org.example;

public interface Terrestre {
    void andar();

}
