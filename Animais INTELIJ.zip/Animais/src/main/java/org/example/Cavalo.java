package org.example;

public class Cavalo extends Animal  implements Terrestre{

    private String raca;

    public Cavalo(String nome, String especie) {
        super(nome, especie);
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    @Override
    public void andar() {
        System.out.println(getNome()+ " esta andando");
    }
}
