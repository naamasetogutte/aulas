package org.example;

import java.util.ArrayList;
import java.util.List;

public class Aluno extends Pessoa{

    List<Professor> professors;
    public Aluno(String nome, int registro) {
        super(nome, registro);
        this.professors = new ArrayList<>();
    }

    public List<Professor> getProfessors() {
        return professors;
    }

    public void cadastrarProfessor(Professor prof){
        professors.add(prof);
    }

}
