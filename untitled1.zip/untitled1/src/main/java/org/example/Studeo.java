package org.example;

public class Studeo {

    public static void main(String[] args) {

        Pessoa joao = new Professor("Joao", 1231);
        Pessoa carlos new Aluno("Carlos", 123213);
        Pessoa naama new Aluno("Naama", 213);
        Pessoa lucas new Professor("Lucas", 21311);


    }

}
