const fs = require('fs');
const readline = require('readline');


class PontoDescarte {
    constructor(endereco, material, horario) {
        this.endereco = endereco;
        this.material = material;
        this.horario = horario;
        this.prox = null; 
    }
}

function criarPonto(endereco, material, horario) {
    return new PontoDescarte(endereco, material, horario);
}

function mostrarPontos(lista, tipoMaterial) {
    let atual = lista;
    let encontrado = false;

    console.log(`\nPontos de descarte para: ${tipoMaterial}\n`);

    while (atual !== null) {
        if (atual.material.toLowerCase() === tipoMaterial.toLowerCase()) {
            console.log(`Endereço: ${atual.endereco}`);
            console.log(`Horário: ${atual.horario}\n`);
            encontrado = true;
        }
        atual = atual.prox;
    }

    if (!encontrado) {
        console.log("Nenhum ponto encontrado para esse tipo de material.\n");
    }
}

function carregarLista() {
    let lista = null;

    try {
        const dados = fs.readFileSync('pontos_de_descartes.txt', 'utf8');
        const linhas = dados.split('\n');

        for (let linha of linhas) {
            if (linha.trim() === '') continue;
            const [endereco, material, horario] = linha.split(';');
            if (endereco && material && horario) {
                const novoPonto = criarPonto(endereco.trim(), material.trim(), horario.trim());
                novoPonto.prox = lista;
                lista = novoPonto;
            }
        }
    } catch (err) {
        console.error("Erro ao abrir o arquivo de dados.");
        process.exit(1);
    }

    return lista;
}

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const lista = carregarLista();

rl.question("Digite o tipo de material (Plastico, Vidro, Eletronicos): ", (tipoMaterial) => {
    mostrarPontos(lista, tipoMaterial);
    rl.close();
});
