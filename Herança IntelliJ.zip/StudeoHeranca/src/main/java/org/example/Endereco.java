package org.example;

public class Endereco {

}
