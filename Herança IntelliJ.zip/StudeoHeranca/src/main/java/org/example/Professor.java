package org.example;

public class Professor extends Pessoa{

    public Professor(String nome, int registro, String endereco) {
        super(nome, registro, endereco);
    }

}
