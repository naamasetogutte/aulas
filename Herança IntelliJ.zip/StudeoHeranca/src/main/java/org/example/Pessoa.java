package org.example;

public class Pessoa {
    private String nome;
    private int registro;
    private String endereco;

    //CONSTRUTOR//
    public Pessoa(String nome, int registro, String endereco) {
        this.nome = nome;
        this.registro = registro;
        this.endereco = endereco;
    }
    //GET E SETT//
    public String getNome() {
        return nome;
    }

    public int getRegistro() {
        return registro;
    }

    public String getEndereco() {
        return endereco;
    }
    //METODOS//

}
