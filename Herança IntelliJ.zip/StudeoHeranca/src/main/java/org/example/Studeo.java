package org.example;

public class Studeo {


    public static void main(String[] args){

        Endereco maringa = new Endereco();

        Pessoa a = new Aluno("Ricardo", 2634, "Sumare");
        Pessoa b = new Professor("Cidao", 98982, "Maringa");
        Pessoa c = new Pessoa("Ricardo", 2634, "Sumare");

        Aluno ademar = new Aluno("Ademar", 123, "Maringa");

        Professor maurilio = new Professor("Maurilio", 123132, "Maringa" );
        Professor joao = new Professor("Joao", 12312, "Maringa");


        


        ademar.addProfessor(maurilio);
        ademar.addProfessor(joao);

        System.out.println("Nome" + ademar.getNome());
        System.out.println("Quais os professores? " + ademar.professores().get(0).getNome());
        System.out.println("Quais os professores? " + ademar.professores().get(1).getNome());
        System.out.println("Quais os professores? " + ademar.professores().get(2).getNome());

        boolean check = true;

        if(check){
            Pessoa cadastro = new Professor("Maurilio", 123132, "Maringa" );
        }else{
            Pessoa cadastro = new Aluno("Ademar", 123, "Maringa");
        }
    }
}
