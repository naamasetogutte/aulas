const fs = require('fs'); // Importa módulo para leitura de arquivos
const readline = require('readline'); // Importa módulo para ler entrada do usuário

// Classe que representa um nó da lista duplamente encadeada
class No {
    constructor(rota) {
        this.rota = rota;   // Conteúdo da rota (ex: "Onibus...")
        this.prox = null;   // Ponteiro para o próximo nó
        this.ant = null;    // Ponteiro para o nó anterior
    }
}

// Classe da Lista Duplamente Encadeada
class ListaDuplamenteEncadeada {
    constructor() {
        this.head = null; // Começo da lista
    }

    // Insere uma nova rota no final da lista
    inserir(rota) {
        const novo = new No(rota); // Cria um novo nó com a rota
        if (!this.head) {
            this.head = novo; // Se a lista estiver vazia, esse será o primeiro nó
        } else {
            let temp = this.head;
            while (temp.prox) { // Navega até o último nó
                temp = temp.prox;
            }
            temp.prox = novo; // Liga o novo nó ao final da lista
            novo.ant = temp;  // Liga o novo nó ao anterior
        }
    }

    // Exibe as rotas na ordem normal (do início ao fim)
    exibirOrdemNormal() {
        console.log("Rotas na ordem normal:");
        let temp = this.head;
        while (temp) {
            console.log(temp.rota); // Imprime a rota atual
            temp = temp.prox;       // Vai para o próximo nó
        }
    }

    // Exibe as rotas na ordem reversa (do fim para o início)
    exibirOrdemReversa() {
        console.log("Rotas na ordem reversa:");
        if (!this.head) return;
        let temp = this.head;
        while (temp.prox) { // Vai até o último nó
            temp = temp.prox;
        }
        while (temp) {
            console.log(temp.rota); // Imprime a rota atual
            temp = temp.ant;        // Volta para o nó anterior
        }
    }

    // Lê o arquivo e carrega apenas as rotas que contêm o tipoFiltro
    carregarRotas(tipoFiltro) {
        try {
            const dados = fs.readFileSync('rotas_de_transportes.txt', 'utf-8');
            const linhas = dados.split('\n');
            for (let linha of linhas) {
                linha = linha.trim(); 
                if (linha.includes(tipoFiltro)) { 
                    this.inserir(linha); 
                }
            }
        } catch (err) {
            console.error("Erro ao abrir o arquivo.");
        }
    }
}

// Função principal: pede ao usuário o tipo de transporte e mostra as rotas filtradas
async function main() {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    // Pede ao usuário o tipo de transporte que deseja visualizar
    rl.question("Digite o tipo de transporte desejado (ex: Onibus, Metro): ", function(tipoFiltro) {
        const lista = new ListaDuplamenteEncadeada(); // Cria a lista
        lista.carregarRotas(tipoFiltro);              
        lista.exibirOrdemNormal();                    
        lista.exibirOrdemReversa();                   
        rl.close();                                   
    });
}

main();
