const fs = require('fs');
const readline = require('readline'); 

class No {
    constructor(rota) {
        this.rota = rota;   
        this.prox = null;  
        this.ant = null;    
    }
}

class ListaDuplamenteEncadeada {
    constructor() {
        this.head = null; 
    }


    inserir(rota) {
        const novo = new No(rota); 
        if (!this.head) {
            this.head = novo; 
        } else {
            let temp = this.head;
            while (temp.prox) { 
                temp = temp.prox;
            }
            temp.prox = novo;
            novo.ant = temp;  
        }
    }

    exibirOrdemNormal() {
        console.log("Rotas na ordem normal:");
        let temp = this.head;
        while (temp) {
            console.log(temp.rota); 
            temp = temp.prox;     
        }
    }

    exibirOrdemReversa() {
        console.log("Rotas na ordem reversa:");
        if (!this.head) return;
        let temp = this.head;
        while (temp.prox) { 
            temp = temp.prox;
        }
        while (temp) {
            console.log(temp.rota);
            temp = temp.ant;      
        }
    }

    carregarRotas(tipoFiltro) {
        try {
            const dados = fs.readFileSync('rotas_de_transportes.txt', 'utf-8');
            const linhas = dados.split('\n');
            for (let linha of linhas) {
                linha = linha.trim(); 
                if (linha.includes(tipoFiltro)) { 
                    this.inserir(linha); 
                }
            }
        } catch (err) {
            console.error("Erro ao abrir o arquivo.");
        }
    }
}

async function main() {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    rl.question("Digite o tipo de transporte desejado (ex: Onibus, Metro): ", function(tipoFiltro) {
        const lista = new ListaDuplamenteEncadeada();
        lista.carregarRotas(tipoFiltro);              
        lista.exibirOrdemNormal();                    
        lista.exibirOrdemReversa();                   
        rl.close();                                   
    });
}

main();
