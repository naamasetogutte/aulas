const fs = require('fs');
const readline = require('readline-sync');

class Veiculo {
  constructor(placa, dia, horario) {
    this.placa = placa;
    this.dia = dia;
    this.horario = horario;
    this.next = null;
  }
}

class ListaCircular {
  constructor() {
    this.inicio = null;
  }

  inserir(placa, dia, horario) {
    const novoVeiculo = new Veiculo(placa, dia, horario);

    if (!this.inicio) {
      this.inicio = novoVeiculo;
      novoVeiculo.next = novoVeiculo;
    } else {
      let atual = this.inicio;
      while (atual.next !== this.inicio) {
        atual = atual.next;
      }
      atual.next = novoVeiculo;
      novoVeiculo.next = this.inicio;
    }
  }

  exibir() {
    if (!this.inicio) {
      console.log("Lista vazia.");
      return;
    }

    let atual = this.inicio;
    do {
      console.log(`Placa: ${atual.placa} | Dia: ${atual.dia} | Horário: ${atual.horario}`);
      atual = atual.next;
    } while (atual !== this.inicio);
  }

  buscarPorDia(diaBusca) {
    let atual = this.inicio;
    let encontrados = [];

    if (!atual) return encontrados;

    do {
      if (atual.dia.toLowerCase() === diaBusca.toLowerCase()) {
        encontrados.push(atual);
      }
      atual = atual.next;
    } while (atual !== this.inicio);

    return encontrados;
  }

  liberar() {
    this.inicio = null;
  }
}

function carregarVeiculos(criterio, tipo) {
  const lista = new ListaCircular();
  const dados = fs.readFileSync("rodizio_de_veiculos.txt", "utf-8");
  const linhas = dados.split("\n");

  for (const linha of linhas) {
    const partes = linha.trim().split(";");
    if (partes.length < 3) continue;

    const [placa, dia, horario] = partes;

    if (
      (tipo === "dia" && dia.toLowerCase() === criterio.toLowerCase()) ||
      (tipo === "placa" && placa.endsWith(criterio))
    ) {
      lista.inserir(placa, dia, horario);
    }
  }

  return lista;
}

function main() {
  console.log("=== Sistema de Rodízio de Veículos ===");

  const tipo = readline.question("Deseja filtrar por dia ou placa? ").toLowerCase();
  let criterio;

  if (tipo === "dia") {
    criterio = readline.question("Digite o dia da semana (ex: Segunda, Terça, Quarta...): ");
  } else if (tipo === "placa") {
    criterio = readline.question("Digite o final da placa (ex: 4): ");
  } else {
    console.log("Critério inválido.");
    return;
  }

  const lista = carregarVeiculos(criterio, tipo);
  console.log("\n--- Veículos encontrados ---");
  lista.exibir();

  let atual = lista.inicio;
  if (!atual) {
    console.log("Nenhum veículo encontrado.");
    return;
  }

  console.log("\n--- Navegando pela lista (circular) ---");
  while (true) {
    console.log(`\nPlaca: ${atual.placa} | Dia: ${atual.dia} | Horário: ${atual.horario}`);
    const opcao = readline.question("Digite [n] para proximo, [s] para sair: ").toLowerCase();

    if (opcao === 's') break;
    atual = atual.next;
  }

  lista.liberar();
  console.log("\nMemória liberada. Programa finalizado.");
}

main();
