package org.example;

public class Calculadora {

    private int numeroA;
    private int numeroB;

    public Calculadora(int numeroA, int numeroB){
        this.numeroA = numeroA;
        this.numeroB = numeroB;
    }

    int somar(){
        return this.numeroA + this.numeroB;
    }
    int subtrair(){
        return this.numeroA - this.numeroB;
    }

    public int getNumeroA(){
        return this.numeroA;
    }

    public void setNumeroA(int numero){
        this.numeroA = numero;
    }

}

