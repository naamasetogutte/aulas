package org.example;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        int nomeVariavel = 10;

        Calculadora calc = new Calculadora(2,2);

        System.out.println("Soma = " + calc.somar());
        System.out.println("Numero A = " + calc.getNumeroA());
        calc.setNumeroA(200);
        System.out.println("Numero A" + calc.getNumeroA());
        }
    }
