package org.example;

import java.util.ArrayList;
import java.util.List;

public class Aluno {

    private String nome;
    private int registroAcademico;
    List<Professor> professores;


    public Aluno(String nome, int registroAcademico) {
        this.nome = nome;
        this.registroAcademico = registroAcademico;
        this.professores = new ArrayList<>();
    }

    public String getNome() {
        return nome;
    }

    public int getRegistroAcademico() {
        return registroAcademico;
    }

    public List<Professor> getProfessores() {
        return professores;
    }

    public void cadastrarProfessor(Professor prof){
        professores.add(prof);
    }

}
