package org.example;

public class Studeo {

    public static void main(String[] args) {
        Aluno carlos = new Aluno("Carlos", 123);

        Aluno lucas = new Aluno("Lucas", 213);


    Professor joao = new Professor("Joao", 2442121);
    Professor moreno = new Professor("Moreno", 213213);


        carlos.cadastrarProfessor(joao);
        carlos.cadastrarProfessor(moreno);

        System.out.println("Qual o registro A = " +carlos.getRegistroAcademico());

        for (int i = 0; i < carlos.getProfessores().size(); i++) {
            System.out.println("O nome do professor é : " +
            carlos.getProfessores().get(i).getNome());
        }
    }
}
