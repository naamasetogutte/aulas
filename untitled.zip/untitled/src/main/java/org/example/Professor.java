package org.example;

import java.util.ArrayList;
import java.util.List;

public class Professor {

    private String nome;
    private int registro;
    List<Aluno> alunos;

    public Professor(String nome, int registro) {
        this.nome = nome;
        this.registro = registro;
        this.alunos = new ArrayList<>();
    }

    public String getNome() {
        return nome;
    }

    public int getRegistro() {
        return registro;
    }

    public List<Aluno> getAlunos(Aluno lucas) {
        return alunos;
    }

    public void addAluno(Aluno aluno){
        alunos.add(aluno);
    }
}
