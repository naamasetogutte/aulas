package org.example;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class LivroTest {

    // entrada de dados
    Livro livro = new Livro ("Casmurro", "Machado", "2005");

    @Test
    public void testGetTitulo(){
        assertEquals("Casmurro", livro.getTitulo());
    }
    @Test
            public void testGetAutor(){
        assertEquals("Machado", livro.getAutor());
    }

    @Test
    public void testGetAnoPublicacao(){
        assertEquals("2005", livro.getAnoPublicacao());
    }

    @Test
    public void testEmprestar(){
    assertTrue(livro.isDisponivel());
    livro.emprestar();
    assertFalse(livro.isDisponivel());
    }


}
