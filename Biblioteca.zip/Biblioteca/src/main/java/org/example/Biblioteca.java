package org.example;

public class Biblioteca {


    public static void main(String[] args){


        int numero = 5;
        String nome = "naamã";


        Livro livro = new Livro("Casmurro", "Machado", "2005");

        System.out.println("***Qual o nome do livro? " + livro.getTitulo());
        System.out.println("*** Qual o autor? " + livro.getAutor());
        System.out.println("***Qual o ano? " + livro.getAnoPublicacao());
        System.out.println("***Esta disponivel? "+ livro.isDisponivel());
    }

}
